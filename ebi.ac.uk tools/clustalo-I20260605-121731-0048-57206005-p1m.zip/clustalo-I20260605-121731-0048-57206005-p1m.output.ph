


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: NP_001268629.1              553 aa
Sequence 2: NP_031531.1                 553 aa
Sequence 3: NP_075581.1                 553 aa
Sequence 4: XP_004855141.1              553 aa
Sequence 5: NP_001001937.1              553 aa
Sequence 6: NP_001129208.1              553 aa
Sequence 7: NP_001253341.1              553 aa
Sequence 8: XP_006085199.1              553 aa
Sequence 9: NP_001274083.1              553 aa
Sequence 10: XP_005612929.1              553 aa
Sequence 11: tr|G3TDU4|G3TDU4_LOXAF      553 aa

           NP_001268629.1 
           NP_031531.1 
           NP_075581.1 
           XP_004855141.1 
           NP_001001937.1 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_031531.1 
           NP_075581.1 
           XP_004855141.1 
           NP_001001937.1 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_075581.1 
           XP_004855141.1 
           NP_001001937.1 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           XP_004855141.1 
           NP_001001937.1 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_001001937.1 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_001129208.1 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_001253341.1 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           XP_006085199.1 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           NP_001274083.1 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           XP_005612929.1 
           tr|G3TDU4|G3TDU4_LOXAF 
           tr|G3TDU4|G3TDU4_LOXAF 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/clustalo/interactive/20260605/1216/clustalo-I20260605-121731-0048-57206005-p1m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/clustalo/interactive/20260605/1216/clustalo-I20260605-121731-0048-57206005-p1m.sqr.ph]

